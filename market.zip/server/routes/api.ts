import { Elysia } from 'elysia';
import type { SearchFilters, EnheterResponse, RollerResponse, CompanyWithRoles } from '../types';

const BRREG_API_BASE = 'https://data.brreg.no/enhetsregisteret/api';

// Helper function to find daglig leder from roles
function findDagligLeder(rollerResponse: RollerResponse): { navn?: string } | undefined {
  if (!rollerResponse.rollegrupper) return undefined;

  for (const gruppe of rollerResponse.rollegrupper) {
    if (!gruppe.roller) continue;
    
    for (const rolle of gruppe.roller) {
      // Check for daglig leder role types
      const rolleKode = rolle.type?.kode;
      if (rolleKode === 'DAGL' || rolleKode === 'DAGLØ' || rolleKode === 'DAGLS') {
        if (rolle.person) {
          const navn = rolle.person.navn || 
            [rolle.person.fornavn, rolle.person.mellomnavn, rolle.person.etternavn]
              .filter(Boolean)
              .join(' ');
          return { navn };
        }
        if (rolle.enhet) {
          return { navn: rolle.enhet.navn };
        }
      }
    }
  }
  return undefined;
}

// Helper to fetch roles for a company
async function fetchRoles(orgnr: string): Promise<{ navn?: string } | undefined> {
  try {
    const response = await fetch(`${BRREG_API_BASE}/enheter/${orgnr}/roller`, {
      headers: {
        'Accept': 'application/vnd.brreg.enhetsregisteret.rolle.v1+json',
      },
    });
    
    if (!response.ok) {
      return undefined;
    }
    
    const data: RollerResponse = await response.json();
    const result = findDagligLeder(data);
    // Ensure we always return an object with navn property, never the full Person object
    if (result && 'navn' in result) {
      return result;
    }
    return undefined;
  } catch (error) {
    console.error(`Error fetching roles for ${orgnr}:`, error);
    return undefined;
  }
}

export const apiRoutes = new Elysia({ prefix: '/api' })
  .get('/search', async ({ query }) => {
    try {
      const filters: SearchFilters = {
        minAksjekapital: query.minAksjekapital ? Number(query.minAksjekapital) : 50000,
        fraRegistreringsdato: query.fraRegistreringsdato as string,
        tilRegistreringsdato: query.tilRegistreringsdato as string,
        organisasjonsform: query.organisasjonsform ? (query.organisasjonsform as string).split(',') : undefined,
        navn: query.navn as string,
        inkluderNaeringskoder: query.inkluderNaeringskoder ? (query.inkluderNaeringskoder as string).split(',').filter(s => s.trim().length > 0) : (query.inkluderNaeringskoder === '' ? [] : undefined),
        ekskluderNaeringskoder: query.ekskluderNaeringskoder ? (query.ekskluderNaeringskoder as string).split(',').filter(s => s.trim().length > 0) : (query.ekskluderNaeringskoder === '' ? [] : undefined),
        page: query.page ? Number(query.page) : 0,
        size: query.size ? Number(query.size) : 100,
      };

      // Debug logging
      console.log('Filters received:', {
        inkluderNaeringskoder: filters.inkluderNaeringskoder,
        ekskluderNaeringskoder: filters.ekskluderNaeringskoder,
      });

      // Build query parameters for Brønnøysundregistrene API
      const params = new URLSearchParams();
      
      if (filters.fraRegistreringsdato) {
        params.append('fraRegistreringsdatoEnhetsregisteret', filters.fraRegistreringsdato);
      }
      
      if (filters.tilRegistreringsdato) {
        params.append('tilRegistreringsdatoEnhetsregisteret', filters.tilRegistreringsdato);
      }
      
      if (filters.organisasjonsform && filters.organisasjonsform.length > 0) {
        params.append('organisasjonsform', filters.organisasjonsform.join(','));
      }
      
      if (filters.navn) {
        params.append('navn', filters.navn);
      }
      
      params.append('page', String(filters.page || 0));
      params.append('size', String(filters.size || 100));
      params.append('sort', 'registreringsdatoEnhetsregisteret,DESC');

      // Fetch companies from Brønnøysundregistrene
      const response = await fetch(`${BRREG_API_BASE}/enheter?${params.toString()}`, {
        headers: {
          'Accept': 'application/vnd.brreg.enhetsregisteret.enhet.v2+json',
        },
      });

      if (!response.ok) {
        throw new Error(`API error: ${response.status}`);
      }

      const data: EnheterResponse = await response.json();
      
      // Filter by minimum aksjekapital (API doesn't support this directly)
      let filteredEnheter = data._embedded?.enheter || [];
      
      if (filters.minAksjekapital) {
        filteredEnheter = filteredEnheter.filter(enhet => {
          const kapital = enhet.kapital?.belop || 0;
          return kapital >= filters.minAksjekapital!;
        });
      }

      // Helper function to check if næringskode matches pattern
      const matchesNaeringskode = (naeringskode: string | undefined, pattern: string): boolean => {
        if (!naeringskode || !pattern) return false;
        const trimmedPattern = pattern.trim();
        if (!trimmedPattern) return false;
        
        // Handle patterns like "47", "47.xx", "70.10"
        if (trimmedPattern.includes('.')) {
          // Exact match for patterns like "70.10" - matches 70.10, 70.10.1, etc.
          return naeringskode.startsWith(trimmedPattern);
        } else {
          // Match prefix for patterns like "47" (matches 47.xx, 47.11, 47.19, etc.)
          // This matches codes that start with "47." or are exactly "47"
          return naeringskode.startsWith(trimmedPattern + '.') || naeringskode === trimmedPattern;
        }
      };

      // Filter by næringskoder
      // First apply exclude filter (remove unwanted codes)
      if (filters.ekskluderNaeringskoder && filters.ekskluderNaeringskoder.length > 0) {
        filteredEnheter = filteredEnheter.filter(enhet => {
          const hovedkode = enhet.naeringskode1?.kode;
          if (!hovedkode) return true; // Include if no næringskode
          
          // Check if any of the exclude patterns match
          const shouldExclude = filters.ekskluderNaeringskoder!.some(pattern => 
            matchesNaeringskode(hovedkode, pattern)
          );
          
          return !shouldExclude;
        });
      }

      // Then apply include filter (only keep wanted codes)
      if (filters.inkluderNaeringskoder && filters.inkluderNaeringskoder.length > 0) {
        filteredEnheter = filteredEnheter.filter(enhet => {
          const hovedkode = enhet.naeringskode1?.kode;
          if (!hovedkode) return false; // Exclude if no næringskode when include filter is active
          
          // Check if any of the include patterns match
          const matches = filters.inkluderNaeringskoder!.some(pattern => 
            matchesNaeringskode(hovedkode, pattern)
          );
          
          return matches;
        });
      }

      // Sort by priority næringskoder first
      if (filters.inkluderNaeringskoder && filters.inkluderNaeringskoder.length > 0) {
        filteredEnheter.sort((a, b) => {
          const aCode = a.naeringskode1?.kode || '';
          const bCode = b.naeringskode1?.kode || '';
          
          const aPriority = filters.inkluderNaeringskoder!.findIndex(pattern => 
            matchesNaeringskode(aCode, pattern)
          );
          const bPriority = filters.inkluderNaeringskoder!.findIndex(pattern => 
            matchesNaeringskode(bCode, pattern)
          );
          
          // If both have priority, sort by priority index (lower = higher priority)
          if (aPriority !== -1 && bPriority !== -1) {
            return aPriority - bPriority;
          }
          // Prioritized items come first
          if (aPriority !== -1) return -1;
          if (bPriority !== -1) return 1;
          return 0;
        });
      }

      // Debug: Log filtered count before fetching roles
      console.log(`Filtered ${filteredEnheter.length} companies after næringskode filtering`);

      // Fetch roles for each company in parallel (limit to avoid too many requests)
      const companiesWithRoles: CompanyWithRoles[] = await Promise.all(
        filteredEnheter.slice(0, 100).map(async (enhet) => {
          const dagligLeder = await fetchRoles(enhet.organisasjonsnummer);
          return {
            ...enhet,
            dagligLeder,
          };
        })
      );

      return {
        companies: companiesWithRoles,
        pagination: data.page,
        links: data._links,
        totalFiltered: filteredEnheter.length,
      };
    } catch (error) {
      console.error('Search error:', error);
      return {
        error: error instanceof Error ? error.message : 'Unknown error',
        companies: [],
        pagination: { number: 0, size: 100, totalPages: 0, totalElements: 0 },
      };
    }
  })
  .get('/companies/:orgnr', async ({ params }) => {
    try {
      const response = await fetch(`${BRREG_API_BASE}/enheter/${params.orgnr}`, {
        headers: {
          'Accept': 'application/vnd.brreg.enhetsregisteret.enhet.v2+json',
        },
      });

      if (!response.ok) {
        throw new Error(`API error: ${response.status}`);
      }

      const data = await response.json();
      return data;
    } catch (error) {
      return {
        error: error instanceof Error ? error.message : 'Unknown error',
      };
    }
  })
  .get('/companies/:orgnr/roles', async ({ params }) => {
    try {
      const response = await fetch(`${BRREG_API_BASE}/enheter/${params.orgnr}/roller`, {
        headers: {
          'Accept': 'application/vnd.brreg.enhetsregisteret.rolle.v1+json',
        },
      });

      if (!response.ok) {
        throw new Error(`API error: ${response.status}`);
      }

      const data: RollerResponse = await response.json();
      const dagligLeder = findDagligLeder(data);
      
      return {
        roles: data,
        dagligLeder,
      };
    } catch (error) {
      return {
        error: error instanceof Error ? error.message : 'Unknown error',
      };
    }
  });

